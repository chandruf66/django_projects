from django.shortcuts import render
from django.core.mail import send_mail,EmailMultiAlternatives
from django.conf import settings



# Create your views here.
def home(request):
    if request.method=='POST':

        sub=request.POST.get('subject')
        msg=request.POST.get('body')
# Example 1
# send_mail(subject, message, from_email, recipient_list)
#message=send_mail(sub,msg , settings.EMAIL_HOST_USER,['gitsutar@gmail.com',])

#example 2
        msg = EmailMultiAlternatives(sub, msg,settings.EMAIL_HOST_USER ,['spoorthip8899@gmail.com'])
        msg.attach('ruby.jpg','/images')
        msg.send()




    return render(request,'mail.html')