from django.shortcuts import render
from .serializer import Contactserializer
from .models import Contact
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.
@api_view(['GET'])
def contact_list(request):
    contacts=Contact.objects.all()
    serializer=Contactserializer(contacts,many=True)
    return Response(serializer.data)